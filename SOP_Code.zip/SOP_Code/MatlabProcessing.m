clear; clc;

% ---- Serial Port Setup ----
port = "COM13";                  % change this to the correct Arduino port
baudRate = 9600;
s = serialport(port, baudRate);
configureTerminator(s, "LF");

flush(s);
pause(2);

% ---- Experiment Parameters ----
duration = 60;            % can be adjusted
dt = 1;                   % can be adjusted
n = duration / dt;
containerHeight_cm = 30;  % adjust to a correct value

% ---- Preallocate Arrays ----
time = zeros(1, n);
flow_m3s = zeros(1, n);
volume_L = zeros(1, n);
waterLevel_cm = zeros(1, n);

% ---- Start Data Collection ----
disp("Reading data from Arduino...");
startTime = datetime('now');

for i = 1:n
    tNow = datetime('now');
    line = readline(s);

    tokens = regexp(line, '([\d.]+)\s+\|+\s+([\d.]+)\s+\|+\s+([\d.]+)', ...  
        'tokens');

    if ~isempty(tokens)
        values = str2double(tokens{1});
        flow_Lmin = values(1);
        volume = values(2);
        level_cm = values(3);

        % Convert to required units
        flow_m3s(i) = (flow_Lmin / 1000) / 60;
        volume_L(i) = volume;
        waterLevel_cm(i) = level_cm;
        time(i) = seconds(tNow - startTime);

        % Print to command window
        fprintf('t=%5.1fs | Flow=%.6f m$^3$/s | Volume=%.2f L | Level=%.2f cm\n', ...
            time(i), flow_m3s(i), volume, level_cm);
    else
        fprintf("Invalid line: %s\n", line);
    end

    pause(dt);
end

% ---- Convert for Plots ----
waterLevel_m = waterLevel_cm / 100;

% ---- Plots ----

% 1. Water Level vs. Time
figure;
plot(time, waterLevel_m, 'b','LineWidth',2);
xlabel('Time (s)'); ylabel('Water Level (m)');
title('Water Level vs. Time'); grid on;

% 2. Flow Rate vs. Water Level
figure;
plot(waterLevel_m, flow_m3s, 'r.','MarkerSize',12);
xlabel('Time (s)'); ylabel('Flow Rate (m^3/s)');
title('Flow Rate vs. Water Level'); grid on;

% 3. Volume vs. Time
figure;
plot(time, volume_L, 'g','LineWidth',2);
xlabel('Time (s)'); ylabel('Total Volume (L)');
title('Volume vs. Time'); grid on;

% Efficiency Estimation
efficiency = flow_m3s ./ waterLevel_m;
figure;
plot(time, efficiency, 'm','LineWidth',2);
xlabel('Time (s)'); ylabel('Flow/Height Ratio');
title('Relative Efficiency vs. Time'); grid on;

% ---- Save Data ----
T = table(time', flow_m3s', volume_L', waterLevel_m', ...
    'VariableNames', {'Time_s', 'Flow_m3s', 'Volume_L', 'WaterLevel_m'});
writetable(T, 'experiment_data.csv');

disp("Data collection complete and saved to 'experiment_data.csv'.");